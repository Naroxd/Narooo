<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AutoController;

Route::apiResource('autos', AutoController::class);