<?php

namespace App\Http\Controllers;

use App\Models\Auto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AutoController extends Controller
{
    // GET /api/autos -> 200 OK
    public function index()
    {
        $autos = Auto::all();
        return response()->json([
            'status' => 200,
            'data' => $autos
        ], 200);
    }

    // POST /api/autos -> 201 Created / 400 Bad Request
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'marca' => 'required|string|max:50',
            'modelo' => 'required|string|max:50',
            'anio' => 'required|integer|digits:4',
            'placa' => 'required|string|max:10|unique:autos,placa',
            'precio' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'message' => 'Error en la validación de datos',
                'errors' => $validator->errors()
            ], 400);
        }

        $auto = Auto::create($request->all());

        return response()->json([
            'status' => 201,
            'message' => 'Auto registrado exitosamente',
            'data' => $auto
        ], 201);
    }

    // GET /api/autos/{id} -> 200 OK / 404 Not Found
    public function show($id)
    {
        $auto = Auto::find($id);

        if (!$auto) {
            return response()->json([
                'status' => 404,
                'message' => 'Auto no encontrado'
            ], 404);
        }

        return response()->json([
            'status' => 200,
            'data' => $auto
        ], 200);
    }

    // PUT/PATCH /api/autos/{id} -> 200 OK / 400 / 404
    public function update(Request $request, $id)
    {
        $auto = Auto::find($id);

        if (!$auto) {
            return response()->json([
                'status' => 404,
                'message' => 'Auto no encontrado'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'marca' => 'sometimes|string|max:50',
            'modelo' => 'sometimes|string|max:50',
            'anio' => 'sometimes|integer|digits:4',
            'placa' => 'sometimes|string|max:10|unique:autos,placa,' . $id,
            'precio' => 'sometimes|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'message' => 'Error en la validación al actualizar',
                'errors' => $validator->errors()
            ], 400);
        }

        $auto->update($request->all());

        return response()->json([
            'status' => 200,
            'message' => 'Auto actualizado correctamente',
            'data' => $auto
        ], 200);
    }

    // DELETE /api/autos/{id} -> 200 OK / 404 Not Found
    public function destroy($id)
    {
        $auto = Auto::find($id);

        if (!$auto) {
            return response()->json([
                'status' => 404,
                'message' => 'Auto no encontrado'
            ], 404);
        }

        $auto->delete();

        return response()->json([
            'status' => 200,
            'message' => 'Auto eliminado exitosamente'
        ], 200);
    }
}